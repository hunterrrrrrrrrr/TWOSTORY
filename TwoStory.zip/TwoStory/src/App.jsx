import React, { useState, useEffect } from 'react'
import { v4 as uuidv4 } from 'uuid'

function App() {
  const [gameState, setGameState] = useState('waiting') // waiting, playing, finished
  const [story, setStory] = useState([])
  const [currentWord, setCurrentWord] = useState('')
  const [players, setPlayers] = useState([])
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState(0)
  const [gameId, setGameId] = useState('')
  const [playerId, setPlayerId] = useState('')
  const [playerName, setPlayerName] = useState('')
  const [showShare, setShowShare] = useState(false)
  const [copied, setCopied] = useState(false)

  // Check if game should start when we have 2 players
  useEffect(() => {
    if (players.length === 2 && gameState === 'waiting') {
      console.log('Starting game with 2 players')
      setGameState('playing')
      localStorage.setItem(`game_${gameId}_state`, 'playing')
    }
  }, [players.length, gameState, gameId])

  // Poll for game updates
  useEffect(() => {
    if (!gameId) return

    const pollInterval = setInterval(() => {
      const storedPlayers = JSON.parse(localStorage.getItem(`game_${gameId}_players`) || '[]')
      const storedState = localStorage.getItem(`game_${gameId}_state`) || 'waiting'
      const storedStory = JSON.parse(localStorage.getItem(`game_${gameId}_story`) || '[]')
      const storedCurrentPlayerIndex = parseInt(localStorage.getItem(`game_${gameId}_currentPlayer`) || '0')
      
      // Debug logging
      if (storedPlayers.length !== players.length) {
        console.log('Player count changed:', players.length, '->', storedPlayers.length)
      }
      
      // Update local state if there are changes
      if (storedPlayers.length !== players.length) {
        setPlayers(storedPlayers)
        // Force check for game start when player count changes
        if (storedPlayers.length === 2 && gameState === 'waiting') {
          console.log('Detected 2 players, starting game')
          setGameState('playing')
          localStorage.setItem(`game_${gameId}_state`, 'playing')
        }
      }
      
      if (storedState !== gameState) {
        console.log('Game state changed:', gameState, '->', storedState)
        setGameState(storedState)
      }
      
      if (storedStory.length !== story.length) {
        setStory(storedStory)
      }
      
      if (storedCurrentPlayerIndex !== currentPlayerIndex) {
        setCurrentPlayerIndex(storedCurrentPlayerIndex)
      }
    }, 100) // Check every 100ms for real-time updates

    return () => clearInterval(pollInterval)
  }, [gameId, players.length, gameState, story.length, currentPlayerIndex])

  // Initialize game on component mount
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const urlGameId = urlParams.get('game')
    
    if (urlGameId) {
      // Join existing game
      setGameId(urlGameId)
      const existingPlayers = JSON.parse(localStorage.getItem(`game_${urlGameId}_players`) || '[]')
      const existingStory = JSON.parse(localStorage.getItem(`game_${urlGameId}_story`) || '[]')
      const existingState = localStorage.getItem(`game_${urlGameId}_state`) || 'waiting'
      const existingCurrentPlayerIndex = parseInt(localStorage.getItem(`game_${urlGameId}_currentPlayer`) || '0')
      
      setPlayers(existingPlayers)
      setStory(existingStory)
      setGameState(existingState)
      setCurrentPlayerIndex(existingCurrentPlayerIndex)
      
      if (existingPlayers.length < 2) {
        // Join as second player
        const newPlayerId = uuidv4()
        const newPlayerName = `Player ${existingPlayers.length + 1}`
        const updatedPlayers = [...existingPlayers, { id: newPlayerId, name: newPlayerName }]
        
        setPlayerId(newPlayerId)
        setPlayerName(newPlayerName)
        setPlayers(updatedPlayers)
        localStorage.setItem(`game_${urlGameId}_players`, JSON.stringify(updatedPlayers))
        
        console.log('Second player joined:', newPlayerName)
        
        // If this makes us have 2 players, start the game immediately
        if (updatedPlayers.length === 2) {
          console.log('Starting game immediately with 2 players')
          setGameState('playing')
          localStorage.setItem(`game_${urlGameId}_state`, 'playing')
        }
      } else {
        // Join as existing player - find which player we are
        const isFirstPlayer = existingPlayers[0] && !playerId
        if (isFirstPlayer) {
          setPlayerId(existingPlayers[0].id)
          setPlayerName(existingPlayers[0].name)
          console.log('Joined as first player:', existingPlayers[0].name)
        } else if (!playerId) {
          // If we don't have a player ID yet, join as second player
          setPlayerId(existingPlayers[1].id)
          setPlayerName(existingPlayers[1].name)
          console.log('Joined as second player:', existingPlayers[1].name)
        }
      }
    } else {
      // Create new game
      const newGameId = uuidv4()
      const newPlayerId = uuidv4()
      const newPlayerName = 'Player 1'
      
      setGameId(newGameId)
      setPlayerId(newPlayerId)
      setPlayerName(newPlayerName)
      
      const newPlayers = [{ id: newPlayerId, name: newPlayerName }]
      setPlayers(newPlayers)
      localStorage.setItem(`game_${newGameId}_players`, JSON.stringify(newPlayers))
      localStorage.setItem(`game_${newGameId}_story`, JSON.stringify([]))
      localStorage.setItem(`game_${newGameId}_state`, 'waiting')
      localStorage.setItem(`game_${newGameId}_currentPlayer`, '0')
      
      console.log('Created new game:', newGameId)
    }
  }, [])

  // Update URL when game ID changes
  useEffect(() => {
    if (gameId) {
      const newUrl = `${window.location.origin}${window.location.pathname}?game=${gameId}`
      window.history.replaceState({}, '', newUrl)
    }
  }, [gameId])

  // Listen for localStorage changes in other tabs/windows
  useEffect(() => {
    if (!gameId) return;
    function handleStorage(e) {
      if (e.key === `game_${gameId}_players` || e.key === `game_${gameId}_state` || e.key === `game_${gameId}_story` || e.key === `game_${gameId}_currentPlayer`) {
        const storedPlayers = JSON.parse(localStorage.getItem(`game_${gameId}_players`) || '[]');
        const storedState = localStorage.getItem(`game_${gameId}_state`) || 'waiting';
        const storedStory = JSON.parse(localStorage.getItem(`game_${gameId}_story`) || '[]');
        const storedCurrentPlayerIndex = parseInt(localStorage.getItem(`game_${gameId}_currentPlayer`) || '0');
        setPlayers(storedPlayers);
        setGameState(storedState);
        setStory(storedStory);
        setCurrentPlayerIndex(storedCurrentPlayerIndex);
      }
    }
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, [gameId]);

  const addWord = () => {
    if (!currentWord.trim()) return
    
    const newStory = [...story, {
      word: currentWord.trim(),
      playerId: playerId,
      playerName: playerName,
      timestamp: Date.now()
    }]
    
    const newCurrentPlayerIndex = (currentPlayerIndex + 1) % 2
    
    // Update local state immediately for instant feedback
    setStory(newStory)
    setCurrentWord('')
    setCurrentPlayerIndex(newCurrentPlayerIndex)
    
    // Save to localStorage for other players
    localStorage.setItem(`game_${gameId}_story`, JSON.stringify(newStory))
    localStorage.setItem(`game_${gameId}_currentPlayer`, newCurrentPlayerIndex.toString())
  }

  const endStory = () => {
    setGameState('finished')
    localStorage.setItem(`game_${gameId}_state`, 'finished')
  }

  const copyShareLink = async () => {
    const shareUrl = `${window.location.origin}${window.location.pathname}?game=${gameId}`
    try {
      await navigator.clipboard.writeText(shareUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea')
      textArea.value = shareUrl
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand('copy')
      document.body.removeChild(textArea)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const isMyTurn = players[currentPlayerIndex]?.id === playerId

  const renderStory = () => {
    return story.map((wordObj, index) => (
      <span key={index} className="word">
        {wordObj.word}
      </span>
    ))
  }

  const renderPlayerInfo = () => {
    return players.map((player, index) => (
      <div 
        key={player.id} 
        className={`player ${players[currentPlayerIndex]?.id === player.id ? 'current-turn' : ''}`}
      >
        <div className="player-avatar">
          {player.name.charAt(player.name.length - 1)}
        </div>
        <div className="player-name">{player.name}</div>
      </div>
    ))
  }

  if (gameState === 'waiting') {
    return (
      <div className="container">
        <h1 className="title">TWOSTORY</h1>
        <p className="subtitle">Collaborative storytelling</p>
        <div className="share-section">
          <h3>Invite someone</h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <input 
              type="text" 
              className="share-link" 
              value={`${window.location.origin}${window.location.pathname}?game=${gameId}`}
              readOnly 
              style={{ margin: 0, flex: 1 }}
            />
            <button className="copy-button" onClick={copyShareLink} style={{ whiteSpace: 'nowrap' }}>
              {copied ? 'Copied!' : 'Copy Link'}
            </button>
          </div>
        </div>
      </div>
    )
  }

  if (gameState === 'finished') {
    return (
      <div className="container">
        <h1 className="title">TWOSTORY</h1>
        <p className="subtitle">The story has ended</p>
        
        <div className="finished-message">✨ Story Complete! ✨</div>
        
        <div className="story-container">
          <div className="story-text">
            {renderStory()}
          </div>
        </div>
        
        <div className="share-section">
          <h3>Share this story:</h3>
          <input 
            type="text" 
            className="share-link" 
            value={`${window.location.origin}${window.location.pathname}?game=${gameId}`}
            readOnly 
          />
          <button className="copy-button" onClick={copyShareLink}>
            {copied ? 'Copied!' : 'Copy Link'}
          </button>
        </div>
        
        <button 
          className="button secondary" 
          onClick={() => window.location.href = window.location.origin}
        >
          Start New Story
        </button>
      </div>
    )
  }

  return (
    <div className="container">
      <h1 className="title">TWOSTORY</h1>
      <p className="subtitle">Take turns adding one word at a time</p>
      
      <div className="story-container">
        <div className="story-text">
          {/* Always show Once Upon a Time... at the start */}
          <span style={{ color: '#999', fontStyle: 'italic', marginRight: 8 }}>
            Once Upon a Time...
          </span>
          {story.map((wordObj, index) => (
            <span key={index} className="word">
              {wordObj.word}
            </span>
          ))}
          {/* In-line input at the end of the story */}
          {gameState === 'playing' && isMyTurn && (
            <input
              type="text"
              className="word-input"
              style={{ display: 'inline-block', width: 'auto', minWidth: 60, marginLeft: 6, marginBottom: 0, verticalAlign: 'middle' }}
              placeholder="..."
              value={currentWord}
              onChange={e => setCurrentWord(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addWord()}
              maxLength={20}
              autoFocus
            />
          )}
        </div>
      </div>
      {/* Remove the input-section entirely */}
      {gameState === 'playing' && (
        <div style={{ marginTop: 24 }}>
          <div className="status">
            {isMyTurn ? 'Your turn!' : 'Waiting for other player...'}
          </div>
          <button 
            className="button danger" 
            onClick={endStory}
            disabled={!isMyTurn}
          >
            The End
          </button>
        </div>
      )}
    </div>
  )
}

export default App 